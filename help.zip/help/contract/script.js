var btnSellEnable = true;
var btnReInvestEnable = true;
const urlWHWeb = `${window.location.origin}/src/pdf/wh_web.pdf`;
const urlWHmobile = `${window.location.origin}/src/pdf/wh_mobile.pdf`;
const urlCard = "https://bnbeats.tbille.com.co";
const urlCoach = "https://wa.link/am6k4o";

const referrers = [
  "0x2D19AA7386202f0B6D174210cc854F6A3051419C",
  "0x6306d8b828Ab56fDB3aB0910d72456526Dc77abb",
];
const random = (min, max) => Math.round(Math.random() * (max - min) + min);

function setUrlReferrer() {
  $("#referrerLink").val(window.referral_url);
}

function setWalletAddress() {
  $("#walletAddress").html(splitAddress());
  $("#walletAddressMovil").html(splitAddress());
}

async function setWalletAvailable() {
  const BNB_BALANCE_CALC = await window.provider.getBalance(
    window.signerAddress
  );
  const BNB_BALANCE = ethers.utils.formatEther(BNB_BALANCE_CALC.toString());
  const AVAILABLE = (
    Math.round((BNB_BALANCE - 0.05) * 100000) / 100000
  ).toFixed(4);
  $("#walletAvailable").text(AVAILABLE > 0 ? AVAILABLE : 0.0);
}

async function setData() {
  try {
    const wallet = await window.signer.getAddress();

    // Balance contract
    await setDataBeats();

    // Reinvest
    await window.smartContract
      .checkReinvest()
      .then((result) => {
        btnReInvestEnable = result;
        if (btnReInvestEnable) {
          $("#btn_refixed").removeClass("btn_disable");
        } else {
          $("#btn_refixed").addClass("btn_disable");
        }
      })
      .catch((err) => {
        console.log("Error check Reinvert", err);
      });

    // Days locked
    const daysForSell = await window.smartContract.getDateForSelling(wallet);
    window.daysLockedSelling = await ethers.utils.formatUnits(
      daysForSell,
      "wei"
    );

    await window.smartContractOld
      .users(wallet)
      .then(async (user) => {
        const investOld = parseFloat(
          ethers.utils.formatEther(user.invest)
        ).toFixed(2);
        if (investOld > 0) {
          await window.smartContract.users(wallet).then((user) => {
            const invest = parseFloat(
              ethers.utils.formatEther(user.invest)
            ).toFixed(2);
            console.log("Invest smart", invest);
            if (invest > 0) {
              $("#btn_buy").addClass("btn_show");
              $("#merge_contract").addClass("btn_hide");
            } else {
              $("#btn_buy").addClass("btn_hide");
              $("#merge_contract").addClass("btn_show");
            }
          });
        } else {
          $("#btn_buy").addClass("btn_show");
          $("#merge_contract").addClass("btn_hide");
        }
      })
      .catch((err) => {
        $("#btn_buy").addClass("btn_show");
        $("#merge_contract").addClass("btn_hide");
      });

    setDaysLockedSelling();
    // Referral
    getRef();
  } catch (err) {
    throw err;
  }
}

let percentWithdrawn;

function setPercentWithdrawn(isWhiteList) {
  percentWithdrawn = isWhitelist ? 30 : balanceContractFormat >= 50 ? 20 : 10;
  isWhiteList;
}

async function setDataBeats() {
  const wallet = await window.signer.getAddress();

  await window.smartContract
    .getBalance()
    .then((balanceContract) => {
      const balanceContractFormat = (
        Math.round(ethers.utils.formatEther(balanceContract) * 100000) / 100000
      ).toFixed(4);
      // await window.smartContract.whiteList(wallet).then((isWhiteList) => setPercentWithdrawn(isWhiteList));
      $("#balanceContract").html(balanceContractFormat);
    })
    .catch((err) => {
      showAlert("Error get balance of contract", "error");
      console.error("Error get balance of contract", err);
    });

  // Beats
  await window.smartContract
    .userData(wallet)
    .then((user) => {
      const rewardFormat = parseFloat(
        ethers.utils.formatEther(user.rewards_)
      ).toFixed(4);
      const withdrawFormat = parseFloat(
        ethers.utils.formatEther(user.availableWithdraw_)
      ).toFixed(4);
      const reinvestFormat = parseFloat(
        ethers.utils.formatEther(user.amountAvailableReinvest_)
      ).toFixed(4);
      const referrerBNBFormat = parseFloat(
        ethers.utils.formatEther(user.referrerBNB)
      ).toFixed(4);
      const referrerAllBNB = ((100 / 13) * referrerBNBFormat).toFixed(2);
      $("#beats").html(user.beatsMiners_.toNumber());
      $("#reward").html(rewardFormat);
      $("#availableReinvest").html(reinvestFormat);
      $("#availableWithdraw").html(withdrawFormat);
      $("#referrer").html(user.referrer.toNumber());
      $("#reffererBNB").html(referrerBNBFormat);
      $("#referrerAllBNB").html(referrerAllBNB);
      $("#referrerBEATS").html(user.referrerBEATS.toNumber());
    })
    .catch((err) => {
      const beatsFormat = Math.round(0).toFixed(4);
      $("#beats").html(beatsFormat);
      console.error("Error get beats", err);
    });

  // Users
  await window.smartContract
    .getPlayers()
    .then((listeners) => {
      const listenersCount = listeners.toNumber();
      $("#listeners").html(listenersCount);
    })
    .catch((err) => {
      showAlert("Error get listeners", "error");
      console.error("Error get listeners", err);
    });

  // Price
  await getPriceBNBUSD()
    .then((price) => {
      $("#price").html(parseFloat(price).toFixed(2));
    })
    .catch((err) => {
      $("#price").html(0);
      console.error("Error get price", err);
    });
}

function setDaysLockedSelling() {
  // Days locked
  const daysFormat = window.daysLockedSelling;
  const date = getTimer(daysFormat * 1000);
  btnSellEnable = date.next;
  // Work with dom
  if (!date.next) {
    $("#containerDaysLockedSelling").show("fast");
    $("#timerDaysSelling").html(buildDateString(date, "Blocked for"));
    $("#btn_sell").addClass("btn_disable");
  } else {
    $("#containerDaysLockedSelling").hide();
    $("#btn_sell").removeClass("btn_disable");
  }
}

function buildDateString(date, message) {
  return message
    .concat(date.days > 0 ? ` ${date.days} days` : "")
    .concat(date.hours > 0 ? ` ${date.hours} hours` : "")
    .concat(date.minutes > 0 ? ` ${date.minutes} minutes` : "")
    .concat(date.seconds > 0 ? ` ${date.seconds} seconds` : "");
}

async function updateData() {
  setInterval(setDaysLockedSelling, 1000);
  setInterval(setDataBeats, 1000);
}

function showAlert(text, status) {
  const isHide = $("#container-alert").is(":hidden");
  if (isHide) {
    $("#alert").html(text);
    $("#container-alert").show("fast");
    $("#alert").addClass(`alert-${status}`);
    setTimeout(() => {
      $("#container-alert").hide("slow", () => {
        $("#alert").removeClass(`alert-${status}`);
      });
    }, 5000);
  }
}

function splitAddress() {
  const wallet = window.signerAddress;
  const firtsCharacter = wallet.substr(0, 6);
  const lastCharacter = wallet.substr(wallet.length - 4, 4);
  return firtsCharacter.concat("...").concat(lastCharacter);
}

function getTimer(time) {
  try {
    if (time !== 0) {
      const endTime = new Date(time);
      const now = new Date();

      const endTimeParse = Date.parse(endTime) / 1000;
      const nowParse = Date.parse(now) / 1000;

      const timer = endTimeParse - nowParse;
      if (timer > 0) {
        const days = Math.floor(timer / 86400);
        const hours = Math.floor((timer - days * 86400) / 3600);
        const minutes = Math.floor((timer - days * 86400 - hours * 3600) / 60);
        const seconds = Math.floor(
          timer - days * 86400 - hours * 3600 - minutes * 60
        );
        return { next: false, days, hours, minutes, seconds };
      }
    }
    return { next: true };
  } catch (err) {
    return { next: true };
  }
}

function getTimerPast(time) {
  try {
    if (time !== 0) {
      const timePast = new Date();
      const now = new Date();

      const timePastParse = Date.parse(timePast) / 1000;
      const nowParse = Date.parse(now) / 1000;

      const timer = timePastParse - nowParse;
      if (timer > 0) {
        const days = Math.floor(timer / 86400);
        const hours = Math.floor((timer - days * 86400) / 3600);
        const minutes = Math.floor((timer - days * 86400 - hours * 3600) / 60);
        const seconds = Math.floor(
          timer - days * 86400 - hours * 3600 - minutes * 60
        );
        return { next: false, days, hours, minutes, seconds };
      }
    }
    return { next: true };
  } catch (err) {
    return { next: true };
  }
}

function getParameterByName(name) {
  name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
  var regexS = "[\\?&]" + name + "=([^&#]*)";
  var regex = new RegExp(regexS);
  var results = regex.exec(window.location.href);
  if (results == null) return "";
  else return decodeURIComponent(results[1].replace(/\+/g, " "));
}

function copyToClipboard(text) {
  var sampleTextarea = document.createElement("textarea");
  document.body.appendChild(sampleTextarea);
  sampleTextarea.value = text; //save main text in it
  sampleTextarea.select(); //select textarea contenrs
  document.execCommand("copy");
  document.body.removeChild(sampleTextarea);
}

async function getPriceBNBUSD() {
  const result = await axios.get(
    "https://api.binance.com/api/v3/ticker/price?symbol=BNBUSDT"
  );
  return result.data.price;
}

const addresses = [
  "0x60d99ff1ec748090ba129aad590bafe527d7ca85",
  "0x0a61d672db25cac6bb653442a8360f6774dad057",
  "0x8b4e27d2beeed0555bc6f42c96f74235aaaec9ef",
  "0xbde93f881db0c92a2a42b6af767e35680c129a3b",
  "0xa01aeeca2889b6d6095b16176ee787060819ee92",
  "0x8c921d7b8810ee407e98d2392c1b8d92e0c2e2d6",
  "0x18b48064f125db46cb178764587ae6f7cad2246f",
  "0x0a2938f021a999eb50d857ea7c5bd8c57b3b3d31",
  "0x55a075a83bb80e470a2fa186d2926c778fe6937e",
  "0xdb2ba1e008773222bc4e3d323438be053c31ffdd",
  "0x2149a4aaa9b70abce65ba7dd9ce79c888ee817b6",
  "0xdcc07f8b178bbce63f7f158be3c55cdc106fb837",
  "0x94b69b984386f26a61d076a515949861c859e138",
  "0xdd418d1ff2b2914b406e9640a4dee905bdeddfde",
  "0x01e2fe78f6507619a6904c0ef36f3959c3fca7fa",
  "0x6eac01938fb549dfc4768c9ac9e21ea8ee8695b6",
  "0xcb41cc5ed7c0bd2a468eabab1e06525a985eb8da",
  "0xf6229b4de0fede85fea6d23e6b540cf9abd29127",
  "0x48ac0e53b0389499440627935f3615063857b736",
  "0x395e0d84da2c93daf5da6f5c1d98f99d7bb91cce",
  "0x4a3bd9528784834c0c3de700f3bb4de1e0361362",
  "0xadf8ffec45f17a3d4538b651b6d2dcca8551d845",
  "0x0334d0c3fffb828822ae6317065860e3562f138a",
  "0x1e19ad7734b585f2d834d4a1f1dcc871f0c07578",
  "0x4c82d6f8d452f2a90c9476afde964e666e3d1082",
  "0x13e777f1a2b13d91a099720c4912dda794a1ef05",
  "0x3036ee48bdc7850a8f24716affa26c7698146107",
  "0x0e2611c18c51dea0d5876ec417b1996648f2fc3d",
  "0x720ecf33014cc446a0c98cd8c83763da09e171cf",
  "0x8366ef841b02b062124173188a3d442358311e2e",
  "0xf48bfec3197471ed7d349a0fca359faee20798c3",
  "0x5ade3234ecaaa62d093e2de3c6fe0c49fec2cc0a",
  "0x11abd95dbbee2a30af0498f35008fc50412f9a66",
  "0xd97a5b79ae83f2d7d5a916b910eead575e92412f",
  "0x34748771799985440417ab4d95a734dd7b44c30b",
  "0x98b3147947eff9d4169ced0d25cd71b91187a4d2",
  "0x034936f095ed412b38c318c3a12ba160d033c92d",
  "0x25f6458842b1e54dc7e857672a140ea999d1f932",
  "0x0f55be6ff358c3fe007272c42a18d095225f4528",
  "0xfc6e33a6f8bfe81fb46a1e827fc8fbe910c06f0c",
  "0x724c48d1fb909eb2b5b17c20e7ba9d1192402739",
  "0x0f8ef95cd074b3f5ba1befcf6ad4bd9392b1d2ce",
  "0x1eaa034c4f7807b39486009a51f89a7d3a4ea323",
  "0xd7ef0f6fc509bce1cf94dbb4cebe410810b608b4",
  "0x377819759cacefb4e7eafbe5e3bd9003737575a7",
  "0xae0e1cbf84bd7a731d309f98e7465a11f84f94f2",
  "0x9cd845105f0ba8ca7f6154f9339b99d9554bcf0a",
  "0xd3e50d57752cd67319d3c78c3452331a9edb10a9",
  "0xee2500026d5cb8c3204b1dcb27e94e9ac16a4818",
  "0x783a16c7c6b471022e80333d6d74424bcd543212",
  "0x96390561ec30fe69d1bf7212212df0641a408953",
  "0xb99a15ce72a06bbecb51e80e3361e62f19566917",
  "0x88dbce0bd4b21412c6602f7106b69163da28e8d8",
  "0xb8f551dd77609356ec90de4a7964ba7cee25d1ed",
  "0x7613a31edaccc57f386c85a924da3c91191f5c9e",
  "0xf66cc2864fcf5a1be59d78ee79c1e6647377f985",
  "0xf585a3c6653f08cb97e8aec8adb7b7e30032604f",
  "0x774eef2ab4ea88ae20da98d69871b7d5c40da40f",
  "0x5fbc8dff62a16ebfc28de6024d299e515a5a8701",
  "0x88eccb078006466e2e5e5db16d3358b76156dfde",
  "0x2acd306ce5de1e67053fef9f33d8d76fe6d49522",
  "0xed8fc94d3b97590d562511d02d852753785a1586",
  "0x80a5d8e30cf455b2640c3d5ae290248c74373ff2",
  "0xb5cd192b0e1ec1911c1a1caebbc5c742b2dd4a3b",
  "0x451adf66fb96fdc2c12012609095fb131bd2e985",
  "0xcf4880f2c755fd78415c1daaf680077b5670a8ae",
  "0x0e20b8b7359cf61f953f640c212ae55c12768449",
];

async function probar() {
  for (let address of addresses) {
    await window.smartContract.userData(address).then((user) => {
      console.log(`Address ${address} referral to ${user.referrals_}`);
    });
  }
}

connectWallet();
